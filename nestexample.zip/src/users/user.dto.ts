export interface userDTO {
    fullName: string;
    birthday: Date;
    isActive: boolean;
}