import { Controller, Post, Body, Get, Put, Delete, Param } from '@nestjs/common';
import { UsersService } from './users.service';
import { User } from './user.entity';
import { UpdateDateColumn } from 'typeorm';


@Controller('users')
export class UsersController {

    constructor(private service: UsersService) { }

    @Get('/getusers')
    get() {
        return this.service.getUsers();
    }
    @Post('/createuser')
    create(@Body() user: User) {
        return this.service.createUser(user);
    }
    @Put('/updateuser/:id')
    update(@Param('id') id: number, @Body() user: Partial<User>) {
        return this.service.updateUser(id, user);
    }
    @Delete('/deleteuser/:id')
    delete(@Param('id') id: number) {
        this.service.deleteUser(id);
        return { Deleted: true }
    }



}