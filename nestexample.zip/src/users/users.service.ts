import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './user.entity';
import { userDTO } from './user.dto';

@Injectable()
export class UsersService {

    constructor(@InjectRepository(User) private usersRepository: Repository<User>) { }
    async getUsers(): Promise<userDTO[]> {
        return await this.usersRepository.find();
    }
    async createUser(userInfo: userDTO) {
        const user = await this.usersRepository.create(userInfo);
        await this.usersRepository.save(user);
        return user;
    }
    async updateUser(id: number, userData) {
        await this.usersRepository.update({ id }, userData);
        return this.usersRepository.findOne({ id });
    }
    async deleteUser(id: number) {
        await this.usersRepository.delete({ id });

    }

}
